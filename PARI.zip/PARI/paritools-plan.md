# paritools implementation plan

This plan maps the useful manuscript utilities into a new `paritools` framework
without making the framework depend on any single programming language.

## Goal

Build PARI as a blueprint compiler: a user-directed compiler that can turn
structured requirements into codebase artifacts, novel artifacts, deterministic
records, tensor/fabric analyses, and reusable reports.

The reference implementation in this repository is Python, but the architecture
uses simple records, lists, maps, integers, strings, JSON, and file paths so it
can be implemented in any general-purpose programming language.

## Utility coverage from `manuscript.md`

| Manuscript layer | Useful utility kept | paritools location |
|---|---|---|
| `1.c` to `6.cpp` | bounded record generation, cartesian/literal/repeat/reverse flows, object specs, dry-run planning, escaping, overwrite checks | `paritools/generation.py`, `paritools/blueprint.py` |
| `0.py` | truth-table validation, canonical Boolean signatures, hash/direct colours, primitive gates, circuit encoding | `paritools/ctce.py` |
| `7.php` | n-dimensional fabric length analysis, capacity comparison, witness data, text analysis, config matching | `paritools/fabric.py` |
| `8.py` | command-gated operating surface concept | `paritools/cli.py` command tree and explicit execution flags |
| `9.py` | accepted colour-index states, tensor coordinates, projections, gate-event derivation, semantic category summaries | `paritools/tensor.py` |
| `10.py` and `11.py` | reversible documentation bundling and export | `paritools/docs.py` |
| `12.md` | scalar/tensor conceptual substrate and user-control emphasis | `paritools/SPEC.md`, `paritools/learning.py` |
| `13.py` to `15.py` | RGB/HEX indexed pixel text parsing and reconstruction pipeline | `paritools/image_text.py` |
| `dictionary.md` | system-level inventory and maintenance map | `paritools/manifest.py`, `paritools/README.md` |

## Control model

The compiler must not take power away from the user as learning develops.
Therefore:

1. Blueprint compilation is dry-run by default.
2. File writes require explicit execution intent.
3. Overwrites require an explicit overwrite flag.
4. Learning has four policy modes: `manual`, `propose`, `hybrid`, and
   `automatic`.
5. Even in automatic mode, only allowlisted actions can be applied.
6. Learning decisions produce audit records.
7. State is ordinary JSON so it can be inspected, copied, reverted, or edited.

## Blueprint compiler contract

A blueprint is a JSON object with these language-neutral fields:

```json
{
  "kind": "codebase",
  "name": "example",
  "requirements": ["requirement text"],
  "files": [{"path": "README.md", "content": "text"}],
  "flows": [
    {
      "name": "handles",
      "flow": "cartesian",
      "alphabet": "abc",
      "width": 2,
      "limit": 9,
      "output": "data/handles.txt"
    }
  ]
}
```

For a novel blueprint, `kind` is `novel` and `chapters` can be supplied:

```json
{
  "kind": "novel",
  "name": "example novel",
  "requirements": ["tone, setting, constraints"],
  "chapters": [
    {"title": "Chapter One", "summary": "What happens here"}
  ]
}
```

## Verification target

The first implementation should pass standard-library unit tests and smoke
commands for:

- manifest reporting;
- record generation;
- CTCE truth-table colour encoding;
- fabric and text matching;
- tensor acceptance/projection/category;
- image pixel text parsing;
- blueprint dry-run and execution;
- learning policy decisions.

