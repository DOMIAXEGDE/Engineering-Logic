import json
import tempfile
import unittest
from pathlib import Path

from paritools.blueprint import compile_blueprint
from paritools.ctce import from_truth_bits
from paritools.fabric import FabricConfig, is_valid_nd_length, match_text, traverse_fabric
from paritools.generation import FlowSpec, generate_values, plan_flow
from paritools.image_text import parse_pixel_lines, pixels_to_hex_lines, pixels_to_rgb_lines
from paritools.learning import LearningKernel, LearningPolicy
from paritools.tensor import accept_state
from paritools.cli import main as cli_main


class ParitoolsTest(unittest.TestCase):
    def test_cartesian_generation(self):
        spec = FlowSpec(name="x", flow="cartesian", alphabet="ab", width=2, limit=4)
        self.assertEqual(list(generate_values(spec)), ["aa", "ab", "ba", "bb"])
        self.assertEqual(plan_flow(spec).total, 4)

    def test_ctce_xor(self):
        xor = from_truth_bits("XOR", "0110")
        self.assertEqual(xor.evaluate(0, 1), 1)
        self.assertEqual(xor.evaluate(1, 1), 0)
        self.assertEqual(xor.input_count, 2)

    def test_fabric(self):
        self.assertTrue(is_valid_nd_length(9, 2))
        rows = traverse_fabric(FabricConfig(7, 10, 5, 2), rows=2)
        self.assertEqual([row.root for row in rows], [2, 3])
        self.assertTrue(match_text("abcd", dimension=2))

    def test_tensor(self):
        state = accept_state("0123", 2)
        self.assertEqual(state.root, 2)
        self.assertEqual(state.coords_for_index(3), (1, 1))
        self.assertEqual(len(state.projection()), 4)
        self.assertIn("objects", state.semantic_category())

    def test_image_text_parse(self):
        rgb = pixels_to_rgb_lines([(255, 0, 0), (0, 255, 0), (0, 0, 255), (1, 2, 3)])
        parsed = parse_pixel_lines(rgb)
        self.assertEqual(parsed[0][1], (255, 0, 0))
        hex_text = pixels_to_hex_lines([rgb for _idx, rgb in parsed])
        self.assertEqual(parse_pixel_lines(hex_text)[3][1], (1, 2, 3))

    def test_learning_policy(self):
        kernel = LearningKernel(LearningPolicy(mode="manual"))
        decision = kernel.decide("suggest", 0.99)
        self.assertEqual(decision.status, "needs_approval")
        blocked = kernel.decide("write_file", 1.0)
        self.assertEqual(blocked.status, "blocked")

    def test_blueprint_dry_run_and_execute(self):
        blueprint = {
            "kind": "codebase",
            "name": "demo",
            "requirements": ["keep it inspectable"],
            "files": [{"path": "src/main.txt", "content": "hello\n"}],
            "flows": [
                {
                    "name": "ids",
                    "flow": "cartesian",
                    "alphabet": "ab",
                    "width": 1,
                    "output": "ids.txt",
                }
            ],
        }
        with tempfile.TemporaryDirectory() as temp:
            out = Path(temp) / "out"
            dry = compile_blueprint(blueprint, out)
            self.assertTrue(dry.dry_run)
            self.assertFalse(out.exists())
            result = compile_blueprint(blueprint, out, execute=True)
            self.assertFalse(result.dry_run)
            self.assertTrue((out / "README.md").exists())
            self.assertEqual((out / "ids.txt").read_text(encoding="utf-8"), "a\nb\n")
            report = json.loads((out / "pari-compile-report.json").read_text(encoding="utf-8"))
            self.assertEqual(report["kind"], "codebase")
            self.assertEqual(report["learning"]["proposals"][0]["action"], "annotate")

    def test_cli_pixels_parse(self):
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "rgb.txt"
            path.write_text(
                "0: rgb(0, 0, 0)\n1: rgb(1, 1, 1)\n2: rgb(2, 2, 2)\n3: rgb(3, 3, 3)\n",
                encoding="utf-8",
            )
            self.assertEqual(cli_main(["pixels", "parse", "--text-file", str(path)]), 0)


if __name__ == "__main__":
    unittest.main()
