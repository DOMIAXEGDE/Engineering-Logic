"""Command line surface for paritools."""

from __future__ import annotations

import argparse
import json
import sys
from dataclasses import asdict, is_dataclass
from pathlib import Path
from typing import Any

from .blueprint import compile_blueprint, load_blueprint
from .ctce import describe_boolean_function, from_truth_bits
from .docs import bundle_tree, export_bundle
from .fabric import FabricConfig, analyze_text, match_text, traverse_fabric, witness
from .generation import FlowSpec, generate_records, plan_flow, write_records
from .image_text import image_to_pixel_text, parse_pixel_lines, reconstruct_png
from .learning import LearningKernel, LearningPolicy
from .manifest import manifest
from .tensor import accept_state


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        result = args.func(args)
    except Exception as exc:  # pragma: no cover - CLI guard
        print(f"paritools: error: {exc}", file=sys.stderr)
        return 1
    if result is not None:
        print_json(result)
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="paritools")
    sub = parser.add_subparsers(required=True)

    p = sub.add_parser("manifest")
    p.set_defaults(func=lambda _args: manifest())

    p = sub.add_parser("generate")
    p.add_argument("--name", default="flow")
    p.add_argument("--flow", choices=["cartesian", "literal", "repeat", "reverse"], default="cartesian")
    p.add_argument("--alphabet", default="")
    p.add_argument("--width", type=int, default=0)
    p.add_argument("--literal", action="append", default=[])
    p.add_argument("--text", default="")
    p.add_argument("--count", type=int, default=1)
    p.add_argument("--limit", type=int)
    p.add_argument("--record-format", choices=["value", "source"], default="value")
    p.add_argument("--out")
    p.add_argument("--execute", action="store_true")
    p.add_argument("--overwrite", action="store_true")
    p.set_defaults(func=cmd_generate)

    p = sub.add_parser("ctce")
    p.add_argument("--name", default="function")
    p.add_argument("--truth-bits", required=True)
    p.set_defaults(func=lambda args: describe_boolean_function(from_truth_bits(args.name, args.truth_bits)))

    p = sub.add_parser("fabric")
    p.add_argument("--p", type=int, required=True)
    p.add_argument("--h", type=int, required=True)
    p.add_argument("--s", type=int, required=True)
    p.add_argument("--dimension", type=int, required=True)
    p.add_argument("--min-root", type=int, default=2)
    p.add_argument("--rows", type=int, default=8)
    p.add_argument("--length", type=int)
    p.set_defaults(func=cmd_fabric)

    p = sub.add_parser("match-text")
    text_group = p.add_mutually_exclusive_group(required=True)
    text_group.add_argument("--text")
    text_group.add_argument("--text-file")
    p.add_argument("--dimension", type=int)
    p.add_argument("--top", type=int, default=8)
    p.set_defaults(func=cmd_match_text)

    p = sub.add_parser("tensor")
    p.add_argument("--state", required=True)
    p.add_argument("--dimension", type=int, required=True)
    p.add_argument("--axis-a", type=int, default=0)
    p.add_argument("--axis-b", type=int, default=1)
    p.set_defaults(func=cmd_tensor)

    p = sub.add_parser("blueprint")
    p.add_argument("--spec", required=True)
    p.add_argument("--out", required=True)
    p.add_argument("--execute", action="store_true")
    p.add_argument("--overwrite", action="store_true")
    p.add_argument("--learning-mode", choices=["manual", "propose", "hybrid", "automatic"], default="manual")
    p.set_defaults(func=cmd_blueprint)

    p = sub.add_parser("bundle")
    p.add_argument("--root", required=True)
    p.add_argument("--out", required=True)
    p.set_defaults(func=lambda args: {"out": str(bundle_tree(args.root, args.out))})

    p = sub.add_parser("export")
    p.add_argument("--doc", required=True)
    p.add_argument("--out", required=True)
    p.add_argument("--overwrite", action="store_true")
    p.set_defaults(func=lambda args: {"written": [str(path) for path in export_bundle(args.doc, args.out, overwrite=args.overwrite)]})

    p = sub.add_parser("pixels")
    pixel_sub = p.add_subparsers(required=True)
    pp = pixel_sub.add_parser("parse")
    pp.add_argument("--text-file", required=True)
    pp.set_defaults(func=cmd_pixels_parse)
    pp = pixel_sub.add_parser("extract")
    pp.add_argument("--image", required=True)
    pp.add_argument("--outdir", required=True)
    pp.add_argument("--greyscale", action="store_true")
    pp.add_argument("--overwrite", action="store_true")
    pp.set_defaults(func=cmd_pixels_extract)
    pp = pixel_sub.add_parser("reconstruct")
    pp.add_argument("--text-file", required=True)
    pp.add_argument("--out", required=True)
    pp.add_argument("--overwrite", action="store_true")
    pp.set_defaults(func=cmd_pixels_reconstruct)

    p = sub.add_parser("learn")
    p.add_argument("--mode", choices=["manual", "propose", "hybrid", "automatic"], default="manual")
    p.add_argument("--action", default="suggest")
    p.add_argument("--confidence", type=float, default=0.5)
    p.add_argument("--user-requested", action="store_true")
    p.set_defaults(func=cmd_learn)

    return parser


def cmd_generate(args: argparse.Namespace) -> dict[str, Any]:
    spec = FlowSpec(
        name=args.name,
        flow=args.flow,
        alphabet=args.alphabet,
        width=args.width,
        literals=tuple(args.literal),
        repeat_text=args.text,
        repeat_count=args.count,
        reverse_text=args.text,
        limit=args.limit,
        output=args.out,
        record_format=args.record_format,
    )
    plan = plan_flow(spec)
    if args.out:
        if args.execute:
            written = write_records(args.out, generate_records(spec), overwrite=args.overwrite)
            return {"plan": plan, "written": written, "out": str(Path(args.out).resolve())}
        return {"plan": plan, "dry_run": True, "message": "pass --execute to write --out"}
    return {"plan": plan, "records": list(generate_records(spec))}


def cmd_fabric(args: argparse.Namespace) -> dict[str, Any]:
    config = FabricConfig(args.p, args.h, args.s, args.dimension, args.min_root)
    result: dict[str, Any] = {"config": config, "rows": traverse_fabric(config, args.rows)}
    if args.length is not None:
        result["witness"] = witness(config, args.length)
    return result


def cmd_match_text(args: argparse.Namespace) -> dict[str, Any]:
    text = args.text if args.text is not None else Path(args.text_file).read_text(encoding="utf-8")
    return {"analysis": analyze_text(text), "matches": match_text(text, dimension=args.dimension, top=args.top)}


def cmd_tensor(args: argparse.Namespace) -> dict[str, Any]:
    state = accept_state(args.state, args.dimension)
    return {
        "summary": state.summary(),
        "projection": state.projection(args.axis_a, args.axis_b),
        "events": state.gate_events(),
        "category": state.semantic_category(),
    }


def cmd_blueprint(args: argparse.Namespace) -> dict[str, Any]:
    result = compile_blueprint(
        load_blueprint(args.spec),
        args.out,
        execute=args.execute,
        overwrite=args.overwrite,
        learning_policy=LearningPolicy(mode=args.learning_mode),
    )
    return {
        "dry_run": result.dry_run,
        "outdir": result.outdir,
        "actions": result.actions,
        "audit": result.audit,
    }


def cmd_learn(args: argparse.Namespace) -> dict[str, Any]:
    kernel = LearningKernel(LearningPolicy(mode=args.mode))
    decision = kernel.decide(args.action, args.confidence, user_requested=args.user_requested)
    return {"decision": decision, "state": kernel.to_dict()}


def cmd_pixels_parse(args: argparse.Namespace) -> dict[str, Any]:
    pixels = parse_pixel_lines(Path(args.text_file).read_text(encoding="utf-8"))
    return {
        "pixel_count": len(pixels),
        "side": int(len(pixels) ** 0.5),
        "first": pixels[0],
        "last": pixels[-1],
    }


def cmd_pixels_extract(args: argparse.Namespace) -> dict[str, Any]:
    outdir = Path(args.outdir)
    rgb_path = outdir / "rgb.txt"
    hex_path = outdir / "hex.txt"
    if not args.overwrite and (rgb_path.exists() or hex_path.exists()):
        raise FileExistsError("rgb.txt or hex.txt exists; pass --overwrite to replace")
    data = image_to_pixel_text(args.image, greyscale=args.greyscale)
    outdir.mkdir(parents=True, exist_ok=True)
    rgb_path.write_text(data["rgb"], encoding="utf-8", newline="\n")
    hex_path.write_text(data["hex"], encoding="utf-8", newline="\n")
    return {"rgb": str(rgb_path.resolve()), "hex": str(hex_path.resolve())}


def cmd_pixels_reconstruct(args: argparse.Namespace) -> dict[str, Any]:
    out = Path(args.out)
    if out.exists() and not args.overwrite:
        raise FileExistsError(f"{out} exists; pass --overwrite to replace")
    target = reconstruct_png(Path(args.text_file).read_text(encoding="utf-8"), out)
    return {"out": str(target.resolve())}


def print_json(value: Any) -> None:
    def default(item: Any) -> Any:
        if is_dataclass(item):
            return asdict(item)
        if isinstance(item, Path):
            return str(item)
        if isinstance(item, tuple):
            return list(item)
        raise TypeError(f"cannot JSON encode {type(item).__name__}")

    print(json.dumps(value, indent=2, sort_keys=True, default=default))
