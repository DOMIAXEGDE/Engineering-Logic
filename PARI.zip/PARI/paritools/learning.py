"""User-controlled learning policy and audit utilities."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from hashlib import sha256
from typing import Any, Literal

LearningMode = Literal["manual", "propose", "hybrid", "automatic"]


@dataclass(frozen=True)
class LearningPolicy:
    mode: LearningMode = "manual"
    auto_threshold: float = 0.95
    allowed_actions: tuple[str, ...] = ("rank", "suggest", "annotate")
    require_checkpoint: bool = True


@dataclass(frozen=True)
class LearningDecision:
    action: str
    confidence: float
    status: Literal["applied", "needs_approval", "blocked"]
    reason: str


@dataclass
class LearningKernel:
    policy: LearningPolicy = field(default_factory=LearningPolicy)
    observations: list[dict[str, Any]] = field(default_factory=list)
    proposals: list[dict[str, Any]] = field(default_factory=list)
    audit: list[dict[str, Any]] = field(default_factory=list)

    def observe(self, kind: str, payload: dict[str, Any]) -> dict[str, Any]:
        record = {
            "kind": kind,
            "payload": payload,
            "timestamp": _now(),
            "hash": sha256(repr(sorted(payload.items())).encode("utf-8")).hexdigest(),
        }
        self.observations.append(record)
        self.audit.append({"event": "observe", **record})
        return record

    def decide(self, action: str, confidence: float, *, user_requested: bool = False) -> LearningDecision:
        if action not in self.policy.allowed_actions:
            decision = LearningDecision(action, confidence, "blocked", "action is not allowlisted")
        elif self.policy.mode == "manual":
            decision = LearningDecision(action, confidence, "needs_approval", "manual mode requires approval")
        elif self.policy.mode == "propose":
            decision = LearningDecision(action, confidence, "needs_approval", "proposal mode never auto-applies")
        elif self.policy.mode == "hybrid":
            if user_requested and confidence >= self.policy.auto_threshold:
                decision = LearningDecision(action, confidence, "applied", "hybrid mode accepted requested action")
            else:
                decision = LearningDecision(action, confidence, "needs_approval", "hybrid mode deferred action")
        elif self.policy.mode == "automatic":
            if confidence >= self.policy.auto_threshold:
                decision = LearningDecision(action, confidence, "applied", "automatic mode threshold met")
            else:
                decision = LearningDecision(action, confidence, "needs_approval", "automatic threshold not met")
        else:
            decision = LearningDecision(action, confidence, "blocked", "unknown learning mode")

        self.audit.append(
            {
                "event": "decide",
                "timestamp": _now(),
                "action": action,
                "confidence": confidence,
                "status": decision.status,
                "reason": decision.reason,
            }
        )
        return decision

    def propose(self, action: str, payload: dict[str, Any], confidence: float) -> dict[str, Any]:
        decision = self.decide(action, confidence)
        proposal = {
            "action": action,
            "payload": payload,
            "confidence": confidence,
            "decision": decision.__dict__,
            "timestamp": _now(),
        }
        self.proposals.append(proposal)
        return proposal

    def to_dict(self) -> dict[str, Any]:
        return {
            "policy": self.policy.__dict__,
            "observations": self.observations,
            "proposals": self.proposals,
            "audit": self.audit,
        }


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()

