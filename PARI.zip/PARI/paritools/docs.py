"""Markdown documentation bundle and export helpers."""

from __future__ import annotations

import re
from pathlib import Path

DEFAULT_IGNORES = {
    ".git",
    ".hg",
    ".svn",
    ".venv",
    "__pycache__",
    "build",
    "dist",
    "node_modules",
    "vendor",
    "venv",
}


def bundle_tree(
    root: str | Path,
    out: str | Path,
    *,
    max_bytes: int = 5_000_000,
    ignore_dirs: set[str] | None = None,
) -> Path:
    source_root = Path(root).resolve()
    output = Path(out).resolve()
    ignores = DEFAULT_IGNORES if ignore_dirs is None else ignore_dirs
    files = [
        path
        for path in sorted(source_root.rglob("*"))
        if path.is_file()
        and not any(part in ignores for part in path.relative_to(source_root).parts)
        and path.resolve() != output
    ]

    lines = ["# Documentation Bundle", "", f"- **Root:** `{source_root}`", "", "## File Contents", ""]
    for index, path in enumerate(files, start=1):
        rel = path.relative_to(source_root).as_posix()
        size = path.stat().st_size
        lines.extend([f"### [{index}] `{rel}`", "", f"- **Bytes:** `{size}`", ""])
        if size > max_bytes:
            lines.extend(["```text", f"[skipped: file exceeds {max_bytes} bytes]", "```", ""])
            continue
        try:
            text = path.read_text(encoding="utf-8")
        except UnicodeDecodeError:
            lines.extend(["```text", "[skipped: non UTF-8 file]", "```", ""])
            continue
        fence = _safe_fence(text)
        lines.extend([f"{fence}{_language_for(path)}", text.rstrip("\n"), fence, ""])
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text("\n".join(lines), encoding="utf-8", newline="\n")
    return output


def export_bundle(doc: str | Path, outdir: str | Path, *, overwrite: bool = False) -> list[Path]:
    text = Path(doc).read_text(encoding="utf-8")
    root = Path(outdir).resolve()
    root.mkdir(parents=True, exist_ok=True)
    pattern = re.compile(
        r"^### \[\d+\] `(?P<path>[^`]+)`\s+.*?^```[^\n]*\n(?P<body>.*?)^```",
        re.MULTILINE | re.DOTALL,
    )
    written: list[Path] = []
    for match in pattern.finditer(text):
        rel = match.group("path")
        body = match.group("body")
        if body.startswith("[skipped:"):
            continue
        target = (root / rel).resolve()
        if root != target and root not in target.parents:
            raise ValueError(f"bundle path escapes output directory: {rel}")
        if target.exists() and not overwrite:
            raise FileExistsError(f"{target} exists; pass overwrite=True to replace it")
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(body, encoding="utf-8", newline="\n")
        written.append(target)
    return written


def _language_for(path: Path) -> str:
    return {
        ".py": "python",
        ".md": "markdown",
        ".json": "json",
        ".c": "c",
        ".cpp": "cpp",
        ".php": "php",
        ".txt": "text",
    }.get(path.suffix.lower(), "text")


def _safe_fence(text: str) -> str:
    fence = "```"
    while fence in text:
        fence += "`"
    return fence

