# paritools

`paritools` is a reference implementation of PARI as a blueprint compiler.
It consolidates the useful utilities documented in
`design-specification/tools-docs/manuscript.md` into a single user-controlled
toolkit.

The package is intentionally made from portable concepts: JSON-compatible
records, deterministic functions, explicit policies, and plain file artifacts.
Python is used here as the reference language, but the interfaces are designed
so the same framework can be rebuilt in any general-purpose language.

## Command examples

```powershell
python -m paritools manifest
python -m paritools generate --alphabet ab --width 2 --limit 4
python -m paritools ctce --name XOR --truth-bits 0110
python -m paritools fabric --p 7 --h 10 --s 5 --dimension 2
python -m paritools match-text --text "hello pari" --dimension 2
python -m paritools tensor --state 0123 --dimension 2
python -m paritools blueprint --spec paritools/examples/codebase-blueprint.json --out pari-build
python -m paritools blueprint --spec paritools/examples/codebase-blueprint.json --out pari-build --execute
```

Blueprint compilation is dry-run by default. Writes require `--execute`, and
overwrites require `--overwrite`.

## Main modules

- `generation.py`: bounded deterministic record generation and object flows.
- `ctce.py`: canonical truth-table colour encoding.
- `fabric.py`: n-dimensional length/fabric analysis and text matching.
- `tensor.py`: accepted state tensors, projections, event summaries, category summaries.
- `docs.py`: reversible Markdown bundle and export helpers.
- `image_text.py`: RGB/HEX indexed pixel text parsing and optional Pillow IO.
- `learning.py`: user-controlled learning policies and audit records.
- `blueprint.py`: blueprint compiler for codebase and novel artifacts.

