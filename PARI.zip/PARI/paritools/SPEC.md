# PARI tools architecture specification

## Core idea

PARI is a point-and-resolve intelligence framework. A user supplies a
blueprint, context, and optional learned state. PARI resolves that input into
explicit artifacts such as files, records, reports, tensor structures, or
fictional-novel material.

## Language-neutral kernel

Any implementation should provide the following pieces.

1. `Tool`
   - name
   - input schema
   - output schema
   - pure function or controlled side-effect function

2. `Blueprint`
   - kind
   - name
   - requirements
   - files
   - flows
   - chapters
   - metadata

3. `Compiler`
   - validate blueprint
   - plan actions
   - apply user policy
   - write artifacts only when authorized
   - emit audit report

4. `LearningKernel`
   - accept observations
   - rank proposals
   - apply or defer by policy
   - write inspectable audit records

5. `ArtifactStore`
   - path-safe writes
   - no overwrite unless authorized
   - deterministic reports

## User-control invariant

Learning may improve ranking, defaults, and proposal quality, but it must never
remove explicit user authority. The invariant is:

```text
no mutation without policy permission, no overwrite without explicit overwrite,
and no hidden learning state that cannot be inspected.
```

## Portable data types

To keep the architecture portable, all interfaces should be expressible through:

- booleans;
- integers;
- strings;
- arrays;
- maps;
- JSON files;
- byte or text files;
- deterministic hashes.

