"""PARI blueprint compiler."""

from __future__ import annotations

import json
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .generation import flow_from_mapping, generate_records, plan_flow
from .learning import LearningKernel, LearningPolicy


@dataclass(frozen=True)
class CompileAction:
    path: str
    content: str
    reason: str
    source: str


@dataclass(frozen=True)
class CompileResult:
    dry_run: bool
    outdir: str
    actions: tuple[CompileAction, ...]
    audit: dict[str, Any]


def load_blueprint(path: str | Path) -> dict[str, Any]:
    return json.loads(Path(path).read_text(encoding="utf-8"))


def compile_blueprint(
    blueprint: dict[str, Any],
    outdir: str | Path,
    *,
    execute: bool = False,
    overwrite: bool = False,
    learning_policy: LearningPolicy | None = None,
) -> CompileResult:
    root = Path(outdir).resolve()
    name = str(blueprint.get("name", "pari-blueprint")).strip() or "pari-blueprint"
    kind = str(blueprint.get("kind", "codebase")).strip().lower() or "codebase"
    requirements = [str(item) for item in blueprint.get("requirements", [])]
    kernel = LearningKernel(learning_policy or LearningPolicy())
    kernel.observe("blueprint", {"name": name, "kind": kind, "requirements": requirements})

    actions: list[CompileAction] = []
    actions.extend(_base_actions(name, kind, requirements))

    for item in blueprint.get("files", []):
        if not isinstance(item, dict):
            raise ValueError("files entries must be objects")
        actions.append(
            CompileAction(
                path=str(item.get("path", "artifact.txt")),
                content=str(item.get("content", "")),
                reason="user-specified blueprint file",
                source="files",
            )
        )

    for item in blueprint.get("flows", []):
        if not isinstance(item, dict):
            raise ValueError("flows entries must be objects")
        flow = flow_from_mapping(item)
        plan = plan_flow(flow)
        output = flow.output or f"generated/{flow.name}.txt"
        content = "\n".join(generate_records(flow))
        if content:
            content += "\n"
        actions.append(
            CompileAction(
                path=output,
                content=content,
                reason=f"generated {flow.flow} flow with total={plan.total} limit={plan.limit}",
                source="flows",
            )
        )

    if kind == "novel":
        actions.extend(_novel_actions(name, requirements, blueprint.get("chapters", [])))

    kernel.propose(
        "annotate",
        {"planned_artifacts": len(actions), "kind": kind},
        confidence=0.9,
    )
    report = _report(name, kind, requirements, actions, kernel)
    actions.append(
        CompileAction(
            path="pari-compile-report.json",
            content=json.dumps(report, indent=2, sort_keys=True) + "\n",
            reason="compiler audit report",
            source="compiler",
        )
    )

    if execute:
        _write_actions(root, actions, overwrite=overwrite)

    return CompileResult(
        dry_run=not execute,
        outdir=str(root),
        actions=tuple(actions),
        audit=report,
    )


def _base_actions(name: str, kind: str, requirements: list[str]) -> list[CompileAction]:
    body = [f"# {name}", "", f"Kind: {kind}", ""]
    if requirements:
        body.append("## Requirements")
        body.extend(f"- {item}" for item in requirements)
        body.append("")
    return [
        CompileAction(
            path="README.md",
            content="\n".join(body),
            reason="human-readable blueprint summary",
            source="compiler",
        )
    ]


def _novel_actions(name: str, requirements: list[str], chapters: Any) -> list[CompileAction]:
    actions: list[CompileAction] = [
        CompileAction(
            path="synopsis.md",
            content=_novel_synopsis(name, requirements),
            reason="novel synopsis from requirements",
            source="novel",
        )
    ]
    if not isinstance(chapters, list) or not chapters:
        chapters = [{"title": "Chapter 1", "summary": "Opening movement generated from the blueprint."}]
    for index, chapter in enumerate(chapters, start=1):
        if isinstance(chapter, dict):
            title = str(chapter.get("title", f"Chapter {index}"))
            summary = str(chapter.get("summary", ""))
        else:
            title = f"Chapter {index}"
            summary = str(chapter)
        content = f"# {title}\n\n{summary}\n\n## Draft scaffold\n\n{_draft_paragraph(name, title, summary)}\n"
        actions.append(
            CompileAction(
                path=f"chapters/{index:02d}-{_slug(title)}.md",
                content=content,
                reason="novel chapter scaffold",
                source="novel",
            )
        )
    return actions


def _novel_synopsis(name: str, requirements: list[str]) -> str:
    lines = [f"# {name} synopsis", ""]
    if requirements:
        lines.append("The story must honor these requirements:")
        lines.extend(f"- {item}" for item in requirements)
    else:
        lines.append("No external requirements were supplied.")
    lines.append("")
    return "\n".join(lines)


def _draft_paragraph(name: str, title: str, summary: str) -> str:
    if summary:
        return f"In `{name}`, `{title}` develops this requirement: {summary}"
    return f"In `{name}`, `{title}` is reserved for a user-directed draft passage."


def _report(
    name: str,
    kind: str,
    requirements: list[str],
    actions: list[CompileAction],
    kernel: LearningKernel,
) -> dict[str, Any]:
    return {
        "name": name,
        "kind": kind,
        "requirements": requirements,
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "action_count": len(actions) + 1,
        "actions": [action.__dict__ for action in actions],
        "learning": kernel.to_dict(),
        "control": {
            "dry_run_default": True,
            "execute_required_for_writes": True,
            "overwrite_requires_flag": True,
        },
    }


def _write_actions(root: Path, actions: list[CompileAction], *, overwrite: bool) -> None:
    root.mkdir(parents=True, exist_ok=True)
    for action in actions:
        target = _safe_target(root, action.path)
        if target.exists() and not overwrite:
            raise FileExistsError(f"{target} exists; pass overwrite=True to replace it")
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(action.content, encoding="utf-8", newline="\n")


def _safe_target(root: Path, relative_path: str) -> Path:
    target = (root / relative_path).resolve()
    if root != target and root not in target.parents:
        raise ValueError(f"path escapes output directory: {relative_path}")
    return target


def _slug(text: str) -> str:
    slug = "".join(ch.lower() if ch.isalnum() else "-" for ch in text)
    slug = "-".join(part for part in slug.split("-") if part)
    return slug or "chapter"
