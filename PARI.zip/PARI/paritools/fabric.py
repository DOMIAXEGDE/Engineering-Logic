"""n-dimensional fabric, length, and text-matching utilities."""

from __future__ import annotations

from dataclasses import dataclass
from hashlib import sha256
from math import isqrt
from typing import Any


@dataclass(frozen=True)
class FabricConfig:
    primary_alphabet_size: int
    secondary_alphabet_size: int
    secondary_length: int
    dimension: int
    min_root: int = 2


@dataclass(frozen=True)
class FabricRow:
    root: int
    length: int
    primary_capacity: int
    secondary_capacity: int
    secondary_exceeds_primary_prefix: bool
    gap: int


@dataclass(frozen=True)
class TextAnalysis:
    length: int
    unique_count: int
    unique_chars: tuple[str, ...]
    preview: str
    sha256: str


def integer_nth_root(value: int, n: int) -> int:
    if value < 0:
        raise ValueError("value cannot be negative")
    if n <= 0:
        raise ValueError("n must be positive")
    if n == 1:
        return value
    if value in (0, 1):
        return value
    if n == 2:
        return isqrt(value)
    lo, hi = 0, 1
    while hi**n <= value:
        hi *= 2
    while lo + 1 < hi:
        mid = (lo + hi) // 2
        if mid**n <= value:
            lo = mid
        else:
            hi = mid
    return lo


def exact_nth_root(value: int, n: int) -> int | None:
    root = integer_nth_root(value, n)
    return root if root**n == value else None


def is_valid_nd_length(length: int, dimension: int, min_root: int = 2) -> bool:
    root = exact_nth_root(length, dimension)
    return root is not None and root >= min_root


def nearest_valid_length(length: int, dimension: int, min_root: int = 2) -> dict[str, int]:
    if length < 0:
        raise ValueError("length cannot be negative")
    root = max(min_root, integer_nth_root(length, dimension))
    lower_root = root if root**dimension <= length else root - 1
    lower_root = max(min_root, lower_root)
    upper_root = lower_root if lower_root**dimension >= length else lower_root + 1
    return {
        "lower_root": lower_root,
        "lower_length": lower_root**dimension,
        "upper_root": upper_root,
        "upper_length": upper_root**dimension,
    }


def analyze_fabric_length(config: FabricConfig, root: int) -> FabricRow:
    if root < config.min_root:
        raise ValueError("root is below min_root")
    length = root**config.dimension
    primary_prefix_capacity = config.primary_alphabet_size ** max(0, length - 1)
    secondary_capacity = config.secondary_alphabet_size**config.secondary_length
    return FabricRow(
        root=root,
        length=length,
        primary_capacity=config.primary_alphabet_size**length,
        secondary_capacity=secondary_capacity,
        secondary_exceeds_primary_prefix=secondary_capacity > primary_prefix_capacity,
        gap=secondary_capacity - primary_prefix_capacity,
    )


def traverse_fabric(config: FabricConfig, rows: int = 8, start_root: int | None = None) -> list[FabricRow]:
    if rows < 0:
        raise ValueError("rows cannot be negative")
    start = config.min_root if start_root is None else max(config.min_root, start_root)
    return [analyze_fabric_length(config, root) for root in range(start, start + rows)]


def witness(config: FabricConfig, length: int) -> dict[str, Any]:
    nearest = nearest_valid_length(length, config.dimension, config.min_root)
    exact = exact_nth_root(length, config.dimension)
    return {
        "input_length": length,
        "dimension": config.dimension,
        "min_root": config.min_root,
        "is_valid": exact is not None and exact >= config.min_root,
        "exact_root": exact,
        "nearest": nearest,
        "config": config.__dict__,
    }


def analyze_text(text: str, preview_limit: int = 80) -> TextAnalysis:
    unique = tuple(sorted(set(text)))
    preview = text[:preview_limit].replace("\n", "\\n").replace("\r", "\\r")
    return TextAnalysis(
        length=len(text),
        unique_count=len(unique),
        unique_chars=unique,
        preview=preview,
        sha256=sha256(text.encode("utf-8")).hexdigest(),
    )


def match_text(
    text: str,
    *,
    dimension: int | None = None,
    dimensions: tuple[int, ...] = (2, 3, 4),
    min_root: int = 2,
    top: int = 8,
) -> list[dict[str, Any]]:
    analysis = analyze_text(text)
    dims = (dimension,) if dimension is not None else dimensions
    candidates: list[dict[str, Any]] = []
    for dim in dims:
        nearest = nearest_valid_length(max(analysis.length, 1), dim, min_root)
        for side in ("lower", "upper"):
            root = nearest[f"{side}_root"]
            candidate_length = nearest[f"{side}_length"]
            distance = abs(candidate_length - analysis.length)
            score = distance + max(0, min_root - root) * 1000
            candidates.append(
                {
                    "dimension": dim,
                    "root": root,
                    "length": candidate_length,
                    "distance": distance,
                    "score": score,
                    "primary_alphabet_size": max(analysis.unique_count, 1),
                    "text_length": analysis.length,
                    "unique_count": analysis.unique_count,
                }
            )
    candidates.sort(key=lambda item: (item["score"], item["dimension"], item["root"]))
    return candidates[:top]

