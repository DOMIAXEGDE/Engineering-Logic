"""Deterministic record and object-flow generation utilities."""

from __future__ import annotations

from dataclasses import dataclass, field
from itertools import islice
from pathlib import Path
from typing import Iterable, Iterator, Literal

FlowName = Literal["cartesian", "literal", "repeat", "reverse"]


@dataclass(frozen=True)
class FlowSpec:
    name: str
    flow: FlowName
    alphabet: str = ""
    width: int = 0
    literals: tuple[str, ...] = ()
    repeat_text: str = ""
    repeat_count: int = 1
    reverse_text: str = ""
    limit: int | None = None
    output: str | None = None
    enabled: bool = True
    record_format: Literal["value", "source"] = "value"
    metadata: dict[str, str] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if self.flow not in {"cartesian", "literal", "repeat", "reverse"}:
            raise ValueError(f"unknown flow: {self.flow}")
        if self.record_format not in {"value", "source"}:
            raise ValueError(f"unknown record format: {self.record_format}")
        if self.width < 0:
            raise ValueError("width cannot be negative")
        if self.repeat_count < 0:
            raise ValueError("repeat count cannot be negative")
        if self.limit is not None and self.limit < 0:
            raise ValueError("limit cannot be negative")


@dataclass(frozen=True)
class GenerationPlan:
    name: str
    flow: FlowName
    total: int
    limit: int | None
    will_truncate: bool
    sample: tuple[str, ...]
    output: str | None


def safe_power(base: int, exponent: int, cap: int | None = None) -> int:
    if base < 0:
        raise ValueError("base cannot be negative")
    if exponent < 0:
        raise ValueError("exponent cannot be negative")
    result = 1
    for _ in range(exponent):
        result *= base
        if cap is not None and result > cap:
            return cap + 1
    return result


def escape_record(value: str) -> str:
    return (
        value.replace("\\", "\\\\")
        .replace("\r", "\\r")
        .replace("\n", "\\n")
        .replace("\t", "\\t")
        .replace('"', '\\"')
    )


def source_record(object_name: str, index: int, value: str) -> str:
    return f'parirecord object="{escape_record(object_name)}" index={index} value="{escape_record(value)}"'


def cartesian_values(
    alphabet: str,
    width: int,
    *,
    start: int = 0,
    limit: int | None = None,
) -> Iterator[str]:
    if width < 0:
        raise ValueError("width cannot be negative")
    if not alphabet and width > 0:
        raise ValueError("alphabet cannot be empty when width is positive")
    if start < 0:
        raise ValueError("start cannot be negative")

    total = len(alphabet) ** width
    stop = total if limit is None else min(total, start + max(0, limit))
    base = len(alphabet)
    for ordinal in range(start, stop):
        if width == 0:
            yield ""
            continue
        n = ordinal
        chars = [""] * width
        for pos in range(width - 1, -1, -1):
            chars[pos] = alphabet[n % base]
            n //= base
        yield "".join(chars)


def literal_values(literals: Iterable[str], *, limit: int | None = None) -> Iterator[str]:
    yield from islice(literals, limit)


def repeat_values(text: str, count: int, *, limit: int | None = None) -> Iterator[str]:
    if count < 0:
        raise ValueError("repeat count cannot be negative")
    yield from islice((text for _ in range(count)), limit)


def reverse_values(text: str, *, limit: int | None = None) -> Iterator[str]:
    yield from islice((text[::-1],), limit)


def _total_for(spec: FlowSpec) -> int:
    if spec.flow == "cartesian":
        return safe_power(len(spec.alphabet), spec.width)
    if spec.flow == "literal":
        return len(spec.literals)
    if spec.flow == "repeat":
        return spec.repeat_count
    if spec.flow == "reverse":
        return 1
    raise ValueError(f"unknown flow: {spec.flow}")


def generate_values(spec: FlowSpec) -> Iterator[str]:
    if not spec.enabled:
        return iter(())
    if spec.flow == "cartesian":
        return cartesian_values(spec.alphabet, spec.width, limit=spec.limit)
    if spec.flow == "literal":
        return literal_values(spec.literals, limit=spec.limit)
    if spec.flow == "repeat":
        return repeat_values(spec.repeat_text, spec.repeat_count, limit=spec.limit)
    if spec.flow == "reverse":
        return reverse_values(spec.reverse_text, limit=spec.limit)
    raise ValueError(f"unknown flow: {spec.flow}")


def generate_records(spec: FlowSpec) -> Iterator[str]:
    for index, value in enumerate(generate_values(spec)):
        if spec.record_format == "source":
            yield source_record(spec.name, index, value)
        else:
            yield value


def plan_flow(spec: FlowSpec, sample_size: int = 8) -> GenerationPlan:
    total = _total_for(spec) if spec.enabled else 0
    limit = spec.limit
    will_truncate = limit is not None and limit < total
    sample = tuple(islice(generate_records(spec), sample_size))
    return GenerationPlan(
        name=spec.name,
        flow=spec.flow,
        total=total,
        limit=limit,
        will_truncate=will_truncate,
        sample=sample,
        output=spec.output,
    )


def write_records(path: str | Path, records: Iterable[str], *, overwrite: bool = False) -> int:
    target = Path(path)
    if target.exists() and not overwrite:
        raise FileExistsError(f"{target} exists; pass overwrite=True to replace it")
    target.parent.mkdir(parents=True, exist_ok=True)
    count = 0
    with target.open("w", encoding="utf-8", newline="\n") as handle:
        for count, record in enumerate(records, start=1):
            handle.write(record)
            handle.write("\n")
    return count


def flow_from_mapping(data: dict[str, object]) -> FlowSpec:
    literals = data.get("literals", ())
    if isinstance(literals, list):
        literals_tuple = tuple(str(item) for item in literals)
    elif isinstance(literals, tuple):
        literals_tuple = tuple(str(item) for item in literals)
    elif isinstance(literals, str):
        literals_tuple = (literals,)
    else:
        literals_tuple = ()

    return FlowSpec(
        name=str(data.get("name", "flow")),
        flow=str(data.get("flow", "cartesian")),  # type: ignore[arg-type]
        alphabet=str(data.get("alphabet", "")),
        width=int(data.get("width", 0)),
        literals=literals_tuple,
        repeat_text=str(data.get("repeat_text", data.get("text", ""))),
        repeat_count=int(data.get("repeat_count", data.get("count", 1))),
        reverse_text=str(data.get("reverse_text", data.get("text", ""))),
        limit=None if data.get("limit") is None else int(data.get("limit", 0)),
        output=None if data.get("output") is None else str(data.get("output")),
        enabled=bool(data.get("enabled", True)),
        record_format=str(data.get("record_format", "value")),  # type: ignore[arg-type]
        metadata={str(k): str(v) for k, v in dict(data.get("metadata", {})).items()},
    )
