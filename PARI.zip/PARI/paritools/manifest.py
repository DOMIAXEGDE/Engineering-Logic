"""Tool inventory derived from the manuscript dictionary."""

from __future__ import annotations

from typing import Any


TOOL_MANIFEST: list[dict[str, Any]] = [
    {
        "name": "generation",
        "module": "paritools.generation",
        "source_layer": "1.c to 6.cpp",
        "purpose": "Bounded deterministic record generation and object flows.",
    },
    {
        "name": "ctce",
        "module": "paritools.ctce",
        "source_layer": "0.py",
        "purpose": "Canonical truth-table colour encoding.",
    },
    {
        "name": "fabric",
        "module": "paritools.fabric",
        "source_layer": "7.php and 9.py",
        "purpose": "n-dimensional fabric lengths, capacity checks, and text matching.",
    },
    {
        "name": "tensor",
        "module": "paritools.tensor",
        "source_layer": "9.py",
        "purpose": "Accepted states, tensor coordinates, projections, events, categories.",
    },
    {
        "name": "docs",
        "module": "paritools.docs",
        "source_layer": "10.py and 11.py",
        "purpose": "Markdown documentation bundle and export.",
    },
    {
        "name": "image_text",
        "module": "paritools.image_text",
        "source_layer": "13.py to 15.py",
        "purpose": "Indexed RGB/HEX pixel text parsing and optional image IO.",
    },
    {
        "name": "learning",
        "module": "paritools.learning",
        "source_layer": "12.md and PARI blueprint",
        "purpose": "User-controlled learning policy, proposal, and audit model.",
    },
    {
        "name": "blueprint",
        "module": "paritools.blueprint",
        "source_layer": "prompt 1",
        "purpose": "Blueprint compiler for codebase and novel artifacts.",
    },
]


def manifest() -> dict[str, Any]:
    return {
        "name": "paritools",
        "version": "0.1.0",
        "architecture": "language-neutral JSON-compatible tool contracts",
        "control_invariant": (
            "dry-run by default; explicit execution for writes; explicit overwrite "
            "for replacement; inspectable learning state"
        ),
        "tools": TOOL_MANIFEST,
    }

