"""Canonical truth-table colour encoding."""

from __future__ import annotations

from dataclasses import dataclass
from hashlib import sha256
from itertools import product
from typing import Callable, Mapping

Bit = int
Bits = tuple[int, ...]
BoolFunc = Callable[..., int]


def as_bit(value: int | bool) -> int:
    return 1 if bool(value) else 0


def require_bits(bits: str) -> str:
    if not bits:
        raise ValueError("truth-table bit string cannot be empty")
    if any(ch not in "01" for ch in bits):
        raise ValueError("truth-table bit string must contain only 0 and 1")
    return bits


def infer_input_count_from_table(bits: str) -> int:
    bits = require_bits(bits)
    length = len(bits)
    if length & (length - 1) != 0:
        raise ValueError("truth-table length must be a power of 2")
    return length.bit_length() - 1


def input_rows(n: int) -> list[Bits]:
    if n < 0:
        raise ValueError("input count cannot be negative")
    return [tuple(row) for row in product((0, 1), repeat=n)]


def int_to_rgb(value: int) -> tuple[int, int, int]:
    value &= 0xFFFFFF
    return ((value >> 16) & 255, (value >> 8) & 255, value & 255)


def rgb_to_hex(rgb: tuple[int, int, int]) -> str:
    return f"#{rgb[0]:02X}{rgb[1]:02X}{rgb[2]:02X}"


def hash_to_rgb(data: str | bytes, salt: str = "CTCE-RGB-v1") -> tuple[int, int, int]:
    if isinstance(data, str):
        data = data.encode("utf-8")
    digest = sha256(salt.encode("utf-8") + b":" + data).digest()
    return int_to_rgb(int.from_bytes(digest[:3], "big"))


def truth_bits_to_direct_rgb(bits: str) -> tuple[int, int, int]:
    bits = require_bits(bits)
    function_id = int(bits, 2)
    max_id = (1 << len(bits)) - 1
    if max_id == 0:
        return (0, 0, 0)
    return int_to_rgb(round((function_id / max_id) * 0xFFFFFF))


def truth_bits_to_multiswatch(signature: str, swatches: int = 4) -> list[str]:
    if swatches <= 0:
        raise ValueError("swatches must be positive")
    digest = sha256(("CTCE-MULTI-v1:" + signature).encode("utf-8")).digest()
    while len(digest) < swatches * 3:
        digest += sha256(digest).digest()
    return [rgb_to_hex(tuple(digest[i * 3 : i * 3 + 3])) for i in range(swatches)]  # type: ignore[list-item]


@dataclass(frozen=True)
class BooleanFunction:
    name: str
    input_count: int
    truth_bits: str

    def __post_init__(self) -> None:
        require_bits(self.truth_bits)
        expected = 1 << self.input_count
        if len(self.truth_bits) != expected:
            raise ValueError(f"{self.name}: expected {expected} bits, got {len(self.truth_bits)}")

    @property
    def function_id(self) -> int:
        return int(self.truth_bits, 2)

    @property
    def canonical_signature(self) -> str:
        return f"CTCE:v1:n={self.input_count}:bits={self.truth_bits}"

    @property
    def canonical_hash(self) -> str:
        return sha256(self.canonical_signature.encode("utf-8")).hexdigest()

    @property
    def direct_hex(self) -> str:
        return rgb_to_hex(truth_bits_to_direct_rgb(self.truth_bits))

    @property
    def hash_hex(self) -> str:
        return rgb_to_hex(hash_to_rgb(self.canonical_signature))

    @property
    def multiswatch(self) -> list[str]:
        return truth_bits_to_multiswatch(self.canonical_signature)

    def evaluate(self, *inputs: int | bool) -> int:
        if len(inputs) != self.input_count:
            raise ValueError(f"{self.name} expects {self.input_count} inputs")
        bits = tuple(as_bit(value) for value in inputs)
        index = int("".join(str(bit) for bit in bits), 2) if bits else 0
        return int(self.truth_bits[index])

    def table_rows(self) -> list[tuple[Bits, int]]:
        return [(row, self.evaluate(*row)) for row in input_rows(self.input_count)]


def from_callable(name: str, input_count: int, func: BoolFunc) -> BooleanFunction:
    bits = "".join(str(as_bit(func(*row))) for row in input_rows(input_count))
    return BooleanFunction(name, input_count, bits)


def from_truth_bits(name: str, bits: str) -> BooleanFunction:
    return BooleanFunction(name, infer_input_count_from_table(bits), bits)


GATES_0_INPUT: dict[str, BooleanFunction] = {
    "FALSE/0": BooleanFunction("FALSE/0", 0, "0"),
    "TRUE/1": BooleanFunction("TRUE/1", 0, "1"),
}

GATES_1_INPUT: dict[str, BooleanFunction] = {
    "BUFFER/IDENTITY": from_callable("BUFFER/IDENTITY", 1, lambda a: a),
    "NOT/INVERTER": from_callable("NOT/INVERTER", 1, lambda a: not a),
}

GATES_2_INPUT: dict[str, BooleanFunction] = {
    "FALSE": from_truth_bits("FALSE", "0000"),
    "AND": from_truth_bits("AND", "0001"),
    "A_AND_NOT_B": from_truth_bits("A_AND_NOT_B", "0010"),
    "A": from_truth_bits("A", "0011"),
    "NOT_A_AND_B": from_truth_bits("NOT_A_AND_B", "0100"),
    "B": from_truth_bits("B", "0101"),
    "XOR": from_truth_bits("XOR", "0110"),
    "OR": from_truth_bits("OR", "0111"),
    "NOR": from_truth_bits("NOR", "1000"),
    "XNOR/EQUIVALENCE": from_truth_bits("XNOR/EQUIVALENCE", "1001"),
    "NOT_B": from_truth_bits("NOT_B", "1010"),
    "A_OR_NOT_B": from_truth_bits("A_OR_NOT_B", "1011"),
    "NOT_A": from_truth_bits("NOT_A", "1100"),
    "NOT_A_OR_B": from_truth_bits("NOT_A_OR_B", "1101"),
    "NAND": from_truth_bits("NAND", "1110"),
    "TRUE": from_truth_bits("TRUE", "1111"),
}

ALIASES = {
    "IMPLY": "NOT_A_OR_B",
    "A_IMPLIES_B": "NOT_A_OR_B",
    "B_IMPLIES_A": "A_OR_NOT_B",
    "PROJECTION_LEFT": "A",
    "PROJECTION_RIGHT": "B",
}


def get_gate(name: str) -> BooleanFunction:
    key = name.strip().upper().replace(" ", "_").replace("-", "_")
    for table in (GATES_0_INPUT, GATES_1_INPUT, GATES_2_INPUT):
        if key in table:
            return table[key]
    if key in ALIASES:
        return GATES_2_INPUT[ALIASES[key]]
    raise KeyError(f"unknown gate: {name}")


@dataclass(frozen=True)
class CircuitNode:
    name: str
    gate: BooleanFunction
    inputs: tuple[int | str, ...]


@dataclass(frozen=True)
class CombinationalCircuit:
    name: str
    input_count: int
    nodes: tuple[CircuitNode, ...]
    outputs: tuple[int | str, ...]

    def evaluate(self, *external_inputs: int | bool) -> Bits:
        if len(external_inputs) != self.input_count:
            raise ValueError(f"{self.name} expects {self.input_count} inputs")
        ext = tuple(as_bit(value) for value in external_inputs)
        memory: dict[str, int] = {}

        def resolve(ref: int | str) -> int:
            return ext[ref] if isinstance(ref, int) else memory[ref]

        for node in self.nodes:
            memory[node.name] = node.gate.evaluate(*(resolve(ref) for ref in node.inputs))
        return tuple(resolve(ref) for ref in self.outputs)

    def output_truth_bits(self) -> str:
        bits: list[str] = []
        for row in input_rows(self.input_count):
            bits.extend(str(bit) for bit in self.evaluate(*row))
        return "".join(bits)

    def colour_encoding(self) -> dict[str, object]:
        bits = self.output_truth_bits()
        signature = f"CTCE:v1:circuit={self.name}:n={self.input_count}:out={len(self.outputs)}:bits={bits}"
        return {
            "name": self.name,
            "input_count": self.input_count,
            "output_count": len(self.outputs),
            "truth_bits": bits,
            "canonical_signature": signature,
            "canonical_hash": sha256(signature.encode("utf-8")).hexdigest(),
            "hash_hex": rgb_to_hex(hash_to_rgb(signature)),
            "multiswatch": truth_bits_to_multiswatch(signature),
        }


def describe_boolean_function(fn: BooleanFunction) -> dict[str, object]:
    return {
        "name": fn.name,
        "input_count": fn.input_count,
        "truth_bits": fn.truth_bits,
        "function_id": fn.function_id,
        "direct_hex": fn.direct_hex,
        "hash_hex": fn.hash_hex,
        "canonical_hash": fn.canonical_hash,
        "multiswatch": fn.multiswatch,
        "table_rows": fn.table_rows(),
    }


def print_encoding(title: str, encoding: Mapping[str, object]) -> None:
    print(title)
    for key, value in encoding.items():
        print(f"{key}: {value}")

