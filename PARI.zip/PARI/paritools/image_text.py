"""Indexed RGB/HEX pixel text utilities."""

from __future__ import annotations

import math
import re
from pathlib import Path
from typing import Iterable

RGB_PATTERN = re.compile(r"^\s*(?P<index>\d+)\s*:\s*rgb\(\s*(?P<r>\d+)\s*,\s*(?P<g>\d+)\s*,\s*(?P<b>\d+)\s*\)\s*$", re.I)
HEX_PATTERN = re.compile(r"^\s*(?P<index>\d+)\s*:\s*#?(?P<hex>[0-9a-f]{6})\s*$", re.I)

Pixel = tuple[int, tuple[int, int, int]]


def parse_pixel_lines(text: str) -> list[Pixel]:
    pixels: list[Pixel] = []
    for line_number, line in enumerate(text.splitlines(), start=1):
        if not line.strip():
            continue
        rgb_match = RGB_PATTERN.match(line)
        if rgb_match:
            rgb = tuple(int(rgb_match.group(ch)) for ch in ("r", "g", "b"))
            _require_rgb(rgb, line_number)
            pixels.append((int(rgb_match.group("index")), rgb))  # type: ignore[arg-type]
            continue
        hex_match = HEX_PATTERN.match(line)
        if hex_match:
            raw = hex_match.group("hex")
            rgb = tuple(int(raw[i : i + 2], 16) for i in (0, 2, 4))
            pixels.append((int(hex_match.group("index")), rgb))  # type: ignore[arg-type]
            continue
        raise ValueError(f"line {line_number} is not RGB or HEX pixel text")
    validate_pixel_sequence(pixels)
    return sorted(pixels, key=lambda item: item[0])


def validate_pixel_sequence(pixels: list[Pixel]) -> int:
    if not pixels:
        raise ValueError("no pixel records found")
    ordered = sorted(index for index, _rgb in pixels)
    expected = list(range(len(ordered)))
    if ordered != expected:
        raise ValueError("pixel indexes must form a continuous zero-based sequence")
    side = math.isqrt(len(ordered))
    if side * side != len(ordered):
        raise ValueError("pixel count must be a perfect square")
    return side


def pixels_to_rgb_lines(pixels: Iterable[tuple[int, int, int]]) -> str:
    lines = []
    for index, rgb in enumerate(pixels):
        _require_rgb(rgb, index + 1)
        lines.append(f"{index}: rgb({rgb[0]}, {rgb[1]}, {rgb[2]})")
    return "\n".join(lines) + "\n"


def pixels_to_hex_lines(pixels: Iterable[tuple[int, int, int]]) -> str:
    lines = []
    for index, rgb in enumerate(pixels):
        _require_rgb(rgb, index + 1)
        lines.append(f"{index}: #{rgb[0]:02X}{rgb[1]:02X}{rgb[2]:02X}")
    return "\n".join(lines) + "\n"


def reconstruct_png(pixel_text: str, out_path: str | Path) -> Path:
    try:
        from PIL import Image
    except ImportError as exc:
        raise RuntimeError("Pillow is required for PNG reconstruction") from exc

    pixels = parse_pixel_lines(pixel_text)
    side = validate_pixel_sequence(pixels)
    image = Image.new("RGB", (side, side))
    image.putdata([rgb for _index, rgb in pixels])
    target = Path(out_path)
    target.parent.mkdir(parents=True, exist_ok=True)
    image.save(target)
    return target


def image_to_pixel_text(image_path: str | Path, *, greyscale: bool = False) -> dict[str, str]:
    try:
        from PIL import Image
    except ImportError as exc:
        raise RuntimeError("Pillow is required for image extraction") from exc

    with Image.open(image_path) as image:
        if image.width != image.height:
            raise ValueError(f"image must be square, got {image.width}x{image.height}")
        converted = image.convert("L" if greyscale else "RGB")
        if greyscale:
            pixels = [(value, value, value) for value in converted.getdata()]
        else:
            pixels = list(converted.getdata())
    return {"rgb": pixels_to_rgb_lines(pixels), "hex": pixels_to_hex_lines(pixels)}


def _require_rgb(rgb: tuple[int, int, int], line_number: int) -> None:
    if len(rgb) != 3 or any(component < 0 or component > 255 for component in rgb):
        raise ValueError(f"line {line_number} has RGB values outside 0..255")

