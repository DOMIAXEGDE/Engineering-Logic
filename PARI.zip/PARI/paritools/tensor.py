"""Accepted state tensor and projection utilities."""

from __future__ import annotations

from dataclasses import dataclass
from hashlib import sha256
from typing import Any

from .fabric import exact_nth_root


@dataclass(frozen=True)
class AcceptedState:
    state: str
    dimension: int
    root: int

    @property
    def shape(self) -> tuple[int, ...]:
        return (self.root,) * self.dimension

    @property
    def alphabet(self) -> tuple[str, ...]:
        return tuple(sorted(set(self.state)))

    def coords_for_index(self, index: int) -> tuple[int, ...]:
        if index < 0 or index >= len(self.state):
            raise IndexError(index)
        coords = [0] * self.dimension
        n = index
        for axis in range(self.dimension - 1, -1, -1):
            coords[axis] = n % self.root
            n //= self.root
        return tuple(coords)

    def points(self) -> list[dict[str, Any]]:
        return [
            {"index": index, "coords": self.coords_for_index(index), "value": value}
            for index, value in enumerate(self.state)
        ]

    def projection(self, axis_a: int = 0, axis_b: int = 1) -> list[dict[str, Any]]:
        if not (0 <= axis_a < self.dimension and 0 <= axis_b < self.dimension):
            raise ValueError("projection axes out of range")
        cells: dict[tuple[int, int], list[str]] = {}
        for point in self.points():
            coords = point["coords"]
            key = (coords[axis_a], coords[axis_b])
            cells.setdefault(key, []).append(str(point["value"]))
        return [
            {"axis_a": key[0], "axis_b": key[1], "values": "".join(values)}
            for key, values in sorted(cells.items())
        ]

    def gate_events(self) -> list[dict[str, Any]]:
        events: list[dict[str, Any]] = []
        for index in range(len(self.state) - 1):
            left = self.state[index]
            right = self.state[index + 1]
            digest = sha256(f"{left}:{right}:{index}".encode("utf-8")).hexdigest()
            events.append(
                {
                    "index": index,
                    "from": left,
                    "to": right,
                    "event_id": digest[:12],
                    "operation": ["hold", "advance", "fold", "emit"][int(digest[0], 16) % 4],
                }
            )
        return events

    def semantic_category(self) -> dict[str, Any]:
        objects = sorted(set(self.state))
        morphisms: dict[str, int] = {}
        for index in range(len(self.state) - 1):
            key = f"{self.state[index]}->{self.state[index + 1]}"
            morphisms[key] = morphisms.get(key, 0) + 1
        return {
            "objects": objects,
            "morphisms": [
                {"name": key, "count": count}
                for key, count in sorted(morphisms.items(), key=lambda item: item[0])
            ],
            "identity_morphisms": [f"id_{obj}" for obj in objects],
        }

    def summary(self) -> dict[str, Any]:
        return {
            "state_length": len(self.state),
            "dimension": self.dimension,
            "root": self.root,
            "shape": self.shape,
            "alphabet": self.alphabet,
            "state_hash": sha256(self.state.encode("utf-8")).hexdigest(),
        }


def accept_state(state: str, dimension: int) -> AcceptedState:
    if not state:
        raise ValueError("state cannot be empty")
    if dimension <= 0:
        raise ValueError("dimension must be positive")
    root = exact_nth_root(len(state), dimension)
    if root is None:
        raise ValueError(f"state length {len(state)} is not an exact {dimension}D tensor length")
    return AcceptedState(state=state, dimension=dimension, root=root)

